// =====================================================================
//  模块化墙面种植系统 v2 — 参数化单元 (OpenSCAD)
//  对标参考图: 倾斜圆柱花盆阵列 + 逐层滴灌 + 底部储水 + 四向拼接
//  单位 mm | FDM 可打印 | 改顶部参数即可调花盆/模块尺寸
// =====================================================================

/* [花盆 Pocket] */
pot_d        = 62;    // 花盆开口内径
pot_depth    = 72;    // 花盆深度(开口到杯底)
pot_tilt     = 30;    // 杯体向后下方倾角(0=水平插入, 越大越陡)
pot_wall     = 2.6;   // (预留)花盆壁厚

/* [模块网格 Grid] */
cols         = 4;     // 每模块花盆列数
rows         = 2;     // 每模块花盆行数
gap_x        = 9;     // 花盆水平净间距
gap_z        = 12;    // 花盆行间净间距

/* [箱体 Shell] */
wall         = 2.6;   // 箱体壁厚
back_gap     = 12;    // 杯底与背板间隙(储水/走水)
reservoir    = 16;    // 底部储水层高度

/* [灌溉 Irrigation] */
drip_d       = 4;     // 杯底滴水孔径(往下层)
vent_d       = 5;     // 透气孔径(开口上沿)
vent_count   = 3;     // 每盆透气孔数

/* [拼接 Interlock] */
join_h       = true;  // 左右横向拼接(燕尾)
join_v       = true;  // 上下堆叠定位(销/孔)
dovetail_w   = 16;    // 燕尾外缘宽
dovetail_t   = 7;     // 燕尾深
peg_d        = 7;     // 堆叠定位销径
join_clear   = 0.3;   // 配合间隙

dev = true;           // true=低精度快预览; 出图/导STL前改 false
$fn = dev ? 32 : 80;

// ---- 派生尺寸 ------------------------------------------------------
pitch_x  = pot_d + gap_x;
pitch_z  = pot_d * 1.05 + gap_z;
mod_w    = cols * pitch_x + gap_x + 2*wall;
mod_h    = reservoir + 2*wall + gap_z + rows * pitch_z;
mod_d    = 2*wall + back_gap + pot_depth*cos(pot_tilt) + pot_d/2*sin(pot_tilt);
corner_r = 6;

function cx(i) = wall + gap_x + pot_d/2 + i*pitch_x;          // 列中心X
function oz(j) = reservoir + wall + gap_z + pot_d/2 + j*pitch_z; // 开口中心Z
front_y = mod_d - wall;                                        // 前内壁Y

// 杯底中心(从开口沿轴向后下方)
function floor_y() = front_y - pot_depth*cos(pot_tilt);
function floor_z(j) = oz(j) - pot_depth*sin(pot_tilt);

// ---- 基础体 -------------------------------------------------------
module rbox(w, d, h, r) {
    hull() for (x=[r, w-r], y=[r, d-r])
        translate([x, y, 0]) cylinder(h=h, r=r);
}

// 单个花盆腔 = 前面板正圆开口 + 向后下斜插杯体
module pocket(i, j) {
    union() {
        // mouth: 前面板上的正圆开口
        translate([cx(i), front_y - 0.1, oz(j)])
            rotate([-90,0,0]) cylinder(h = wall + 1, d = pot_d);
        // cup: 从开口往箱内后下方斜插
        translate([cx(i), front_y, oz(j)])
            rotate([90 + pot_tilt, 0, 0]) cylinder(h = pot_depth, d = pot_d);
    }
}

// ---- 主模块 -------------------------------------------------------
module unit() {
    difference() {
        rbox(mod_w, mod_d, mod_h, corner_r);

        // 1) 花盆阵列
        for (i=[0:cols-1], j=[0:rows-1]) pocket(i, j);

        // 2) 杯底滴水孔(最低点向下穿到箱底)
        for (i=[0:cols-1], j=[0:rows-1])
            translate([cx(i), floor_y() + pot_d*0.25, -0.5])
                cylinder(h = floor_z(j) + 1, d = drip_d);

        // 3) 透气孔(开口上沿前面板)
        for (i=[0:cols-1], j=[0:rows-1], k=[0:vent_count-1])
            translate([cx(i) - pot_d/3 + k*(pot_d/3),
                       front_y - 0.1, oz(j) + pot_d/2 + 4])
                rotate([-90,0,0]) cylinder(h = wall + 1, d = vent_d);

        // 4) 储水层溢流孔(每列一个, 超水位往下层)
        for (i=[0:cols-1])
            translate([cx(i), mod_d/2, -0.5]) cylinder(h = reservoir, d = drip_d);

        // 5) 左侧燕尾母槽
        if (join_h)
            translate([-0.1, mod_d/2, mod_h*0.25]) dovetail(female=true);

        // 6) 顶面堆叠定位孔
        if (join_v)
            for (sx=[mod_w*0.25, mod_w*0.75])
                translate([sx, mod_d/2, mod_h - 8]) cylinder(h = 9, d = peg_d + join_clear);
    }

    // 7) 右侧燕尾公榫
    if (join_h)
        translate([mod_w - 1, mod_d/2, mod_h*0.25]) dovetail(female=false);

    // 8) 底面堆叠定位销
    if (join_v)
        for (sx=[mod_w*0.25, mod_w*0.75])
            translate([sx, mod_d/2, -7]) cylinder(h = 8, d = peg_d);
}

// 燕尾(沿+X伸出/凹入), female=true 为放大可减槽体
module dovetail(female=false) {
    c = female ? -join_clear : join_clear;
    h = mod_h * 0.5;
    rotate([0,90,0]) linear_extrude(dovetail_t + (female?0.2:0))
        polygon([[-dovetail_w/2+c, 0],
                 [ dovetail_w/2-c, 0],
                 [ dovetail_w/2-dovetail_t-c, h],
                 [-dovetail_w/2+dovetail_t+c, h]]);
}

unit();
echo(str("模块外形 W x D x H = ", mod_w, " x ", mod_d, " x ", mod_h, " mm"));
